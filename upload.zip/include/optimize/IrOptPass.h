#ifndef IR_OPT_PASS_H
#define IR_OPT_PASS_H
class IrModule;
void memToReg(IrModule& module);
#endif